package baseclient.gg.dhyeybg.baseclient.module.combat;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Configurable single-player combat helper.
 *
 * Settings below can be changed in source. This module fails closed outside
 * an integrated single-player world and uses the normal Minecraft attack
 * cooldown. Through-wall targeting is intentionally available only offline.
 */
public class KillAura extends Module {

    // Configuration (edit these values before compiling).
    public static double MAX_RANGE = 6.0D; // hard maximum: 6 blocks
    public static boolean TARGET_PLAYERS = true;
    public static boolean TARGET_HOSTILE_MOBS = true;
    public static boolean TARGET_PASSIVE_MOBS = true;
    public static boolean ATTACK_THROUGH_WALLS = true;
    public static boolean RESPECT_ATTACK_COOLDOWN = true;

    private static final double HARD_MAX_RANGE = 6.0D;

    public KillAura() {
        super("KillAura", "Configurable single-player auto-attack", Category.COMBAT);
    }

    @Override
    public void onUpdate() {
        if (mc.world == null || mc.player == null || mc.playerController == null) {
            return;
        }

        // Fail closed: never operate in a multiplayer world/server.
        if (!mc.isSingleplayer()) {
            setToggled(false);
            return;
        }

        if (mc.currentScreen != null || mc.player.isHandActive()) {
            return;
        }

        if (RESPECT_ATTACK_COOLDOWN && mc.player.getCooledAttackStrength(0.0F) < 1.0F) {
            return;
        }

        EntityLivingBase target = findNearestTarget();
        if (target != null) {
            mc.playerController.attackEntity(mc.player, target);
            mc.player.swingArm(net.minecraft.util.EnumHand.MAIN_HAND);
        }
    }

    private EntityLivingBase findNearestTarget() {
        EntityLivingBase bestTarget = null;
        double configuredRange = Math.max(0.0D, Math.min(MAX_RANGE, HARD_MAX_RANGE));
        double bestDistanceSq = configuredRange * configuredRange;

        for (Entity entity : mc.world.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase)) {
                continue;
            }

            EntityLivingBase living = (EntityLivingBase) entity;
            if (living == mc.player || !living.isEntityAlive() || living.isDead) {
                continue;
            }

            if (!isTargetEnabled(living)) {
                continue;
            }

            double distanceSq = mc.player.getDistanceSqToEntity(living);
            if (distanceSq > bestDistanceSq) {
                continue;
            }

            // This can be turned off in source config. Only reachable while single-player is active.
            if (!ATTACK_THROUGH_WALLS && !mc.player.canEntityBeSeen(living)) {
                continue;
            }

            bestDistanceSq = distanceSq;
            bestTarget = living;
        }

        return bestTarget;
    }

    private boolean isTargetEnabled(EntityLivingBase entity) {
        if (entity instanceof EntityPlayer) {
            return TARGET_PLAYERS;
        }
        if (entity instanceof IMob) {
            return TARGET_HOSTILE_MOBS;
        }
        if (entity instanceof EntityAnimal || entity instanceof EntityAmbientCreature
                || entity instanceof EntityWaterMob) {
            return TARGET_PASSIVE_MOBS;
        }
        // Other living entities are treated as passive/neutral mobs.
        return TARGET_PASSIVE_MOBS;
    }
}
