#!/usr/bin/env bash
set -euo pipefail
manager="src/main/java/baseclient/gg/dhyeybg/baseclient/module/ModuleManager.java"
source_file="src/main/java/baseclient/gg/dhyeybg/baseclient/module/combat/KillAura.java"
if [[ ! -f "$manager" || ! -f "$source_file" ]]; then
  echo "Run this script from the project root after extracting the patch."
  echo "Missing expected file: $manager or $source_file"
  exit 1
fi
if ! grep -q 'new KillAura()' "$manager"; then
  cp "$manager" "$manager.before-killaura.bak"
  python3 - "$manager" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
needle = '\t\tthis.modules.add(new Velocity());'
if needle not in s:
    raise SystemExit('Could not find the Velocity registration. No changes were made to ModuleManager.java.')
s = s.replace(needle, '\t\tthis.modules.add(new KillAura());\n' + needle, 1)
p.write_text(s)
PY
  echo "Registered KillAura in ModuleManager.java (backup: ModuleManager.java.before-killaura.bak)."
else
  echo "KillAura is already registered in ModuleManager.java."
fi
echo "KillAura installed: single-player only, 6-block hard range cap, configurable target types and through-wall targeting."
