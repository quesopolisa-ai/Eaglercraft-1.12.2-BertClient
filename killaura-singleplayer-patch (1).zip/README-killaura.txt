Restricted single-player KillAura patch

Settings are in KillAura.java and are configurable before compiling:
- MAX_RANGE = 6.0D (clamped so it cannot exceed 6 blocks)
- TARGET_PLAYERS = true
- TARGET_HOSTILE_MOBS = true
- TARGET_PASSIVE_MOBS = true
- ATTACK_THROUGH_WALLS = true
- RESPECT_ATTACK_COOLDOWN = true

Safety behavior:
- The module automatically disables itself when mc.isSingleplayer() is false.
- The module only runs in an active integrated single-player world.
- It respects the normal attack cooldown by default.
- Range is hard-capped at 6 blocks.

Note: player entities are included as a configurable target type, but a normal
single-player world usually has no other player entities. Through-wall targeting
is enabled by default for the offline world only.

Install from the project root in GitHub Codespaces:
  unzip -o killaura-singleplayer-patch.zip -d .
  bash apply-killaura.sh
  ./CompileJS.sh

After a successful compile:
  ./MakeOfflineDownload.sh

The script only inserts the KillAura registration into ModuleManager.java if it
is not already present, preserving other existing registrations.
