BASECLIENT UTILITIES MODULES PATCH

This archive is based on the preceding movement-modules archive and includes its combat/movement modules.

New utilities:
- XRay: registered toggle only; actual see-through-block rendering requires a WorldRenderer/block render hook.
- Freecam: registered toggle only; detached camera needs EntityRenderer and input hooks.
- AutoTool: selects the hotbar slot with the best destroy speed for the block under the crosshair.
- AutoTotem: detects totems but does not auto-move them yet; inventory click handling varies by fork and needs a tested container hook.
- AutoEat: attempts to eat held food below the configured hunger threshold.
- AutoFish: basic local bobber-bite detection; behavior can vary by Eaglercraft fork.
- FastPlace: clears local right-click delay.
- Timer: adjusts local tick length; restores original tick length when disabled.

Existing FullBright is preserved and NOT duplicated.

This is a source patch, not a guaranteed compiled client. The supplied source archive is partial; build/test against the full Eaglercraft 1.12.2 source tree. Test only in single-player. Some Minecraft/Eaglercraft forks rename fields or omit APIs used by these modules.
