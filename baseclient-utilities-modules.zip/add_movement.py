from pathlib import Path
root=Path('/tmp/movezip/src/main/java/baseclient/gg/dhyeybg/baseclient/module/movement')
root.mkdir(parents=True, exist_ok=True)
files={
'NoFall.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Resets local fall distance; intended for single-player testing. */
public class NoFall extends Module {
 public NoFall(){ super("NoFall", "Prevents fall damage in single-player", Category.MOVEMENT); }
 @Override public void onUpdate(){ if(mc.player != null && mc.isSingleplayer()) mc.player.fallDistance = 0.0F; }
}
''',
'Fly.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class Fly extends Module {
 private final Setting speed = Setting.textBox("Vertical Speed", this, 0.35D, 0.05D, 1.5D);
 public Fly(){ super("Fly", "Simple local flight controls for single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(speed); }
 @Override public void onUpdate(){ if(mc.player == null || !mc.isSingleplayer()) return; if(mc.gameSettings.keyBindJump.isKeyDown()) mc.player.motionY = speed.getValDouble(); else if(mc.gameSettings.keyBindSneak.isKeyDown()) mc.player.motionY = -speed.getValDouble(); else mc.player.motionY = 0.0D; mc.player.fallDistance = 0.0F; }
 @Override public void onDisable(){ if(mc.player != null) mc.player.motionY = 0.0D; }
}
''',
'Speed.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class Speed extends Module {
 private final Setting multiplier = Setting.textBox("Multiplier", this, 1.35D, 1.05D, 2.5D);
 public Speed(){ super("Speed", "Increases ground movement speed in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(multiplier); }
 @Override public void onUpdate(){ if(mc.player == null || !mc.isSingleplayer() || mc.player.movementInput == null) return; double f=mc.player.movementInput.moveForward, s=mc.player.movementInput.moveStrafe; if(f==0.0D && s==0.0D) return; float yaw=mc.player.rotationYaw; if(f!=0.0D){ if(s>0) yaw += f>0? -45:45; else if(s<0) yaw += f>0?45:-45; s=0; f=f>0?1:-1; } double r=Math.toRadians(yaw); double scale=0.1D*(multiplier.getValDouble()-1.0D); mc.player.motionX += (-Math.sin(r)*f + Math.cos(r)*s)*scale; mc.player.motionZ += (Math.cos(r)*f + Math.sin(r)*s)*scale; }
}
''',
'HighJump.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class HighJump extends Module {
 private final Setting height=Setting.textBox("Height", this, 0.65D, 0.42D, 1.5D); private boolean wasOnGround;
 public HighJump(){ super("HighJump", "Boosts each grounded jump in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(height); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.onGround && mc.player.movementInput.jump && !wasOnGround) mc.player.motionY=height.getValDouble(); wasOnGround=mc.player.onGround; }
 @Override public void onDisable(){ wasOnGround=false; }
}
''',
'LongJump.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class LongJump extends Module {
 private final Setting boost=Setting.textBox("Boost", this, 0.35D, 0.05D, 1.0D); private boolean wasOnGround;
 public LongJump(){ super("LongJump", "Adds a forward jump boost in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(boost); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.onGround && mc.player.movementInput.jump && !wasOnGround){ double f=mc.player.movementInput.moveForward, s=mc.player.movementInput.moveStrafe; if(f!=0 || s!=0){ double yaw=Math.toRadians(mc.player.rotationYaw); mc.player.motionX += (-Math.sin(yaw)*f + Math.cos(yaw)*s)*boost.getValDouble(); mc.player.motionZ += (Math.cos(yaw)*f + Math.sin(yaw)*s)*boost.getValDouble(); } } wasOnGround=mc.player.onGround; }
 @Override public void onDisable(){ wasOnGround=false; }
}
''',
'Step.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class Step extends Module {
 private final Setting height=Setting.textBox("Height", this, 1.0D, 0.6D, 2.5D); private float oldHeight=0.6F;
 public Step(){ super("Step", "Steps up higher blocks in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(height); }
 @Override public void onEnable(){ if(mc.player!=null){ oldHeight=mc.player.stepHeight; mc.player.stepHeight=(float)height.getValDouble(); } }
 @Override public void onUpdate(){ if(mc.player!=null && mc.isSingleplayer()) mc.player.stepHeight=(float)height.getValDouble(); }
 @Override public void onDisable(){ if(mc.player!=null) mc.player.stepHeight=0.6F; }
}
''',
'Jesus.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
public class Jesus extends Module {
 public Jesus(){ super("Jesus", "Keeps the player afloat on water in single-player", Category.MOVEMENT); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.isInWater() && !mc.player.isSneaking() && mc.player.motionY < 0.0D) mc.player.motionY=0.08D; }
}
''',
'Spider.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
public class Spider extends Module {
 public Spider(){ super("Spider", "Climbs walls when colliding in single-player", Category.MOVEMENT); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.isCollidedHorizontally && (mc.player.movementInput.moveForward!=0 || mc.player.movementInput.moveStrafe!=0)) mc.player.motionY=0.2D; }
}
''',
'NoSlow.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Module flag only: vanilla slowdown is applied in movement/input code and needs a hook to fully cancel. */
public class NoSlow extends Module {
 public NoSlow(){ super("NoSlow", "No-slow module flag; requires a movement-input hook", Category.MOVEMENT); }
}
''',
'SafeWalk.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Needs an Entity movement/collision hook to prevent walking off edges reliably. */
public class SafeWalk extends Module {
 public SafeWalk(){ super("SafeWalk", "Safe-walk module flag; requires a movement hook", Category.MOVEMENT); }
}
''',
'InventoryMove.java':'''package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Requires a GuiScreen/KeyBinding hook because vanilla screens suppress movement input. */
public class InventoryMove extends Module {
 public InventoryMove(){ super("InventoryMove", "Inventory movement flag; requires a GUI input hook", Category.MOVEMENT); }
}
'''
}
for n,s in files.items(): (root/n).write_text(s)
