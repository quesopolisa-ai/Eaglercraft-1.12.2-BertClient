BaseClient Combat Modules — integration notes

Included modules: AimAssist, Reach, AutoClicker, TriggerBot. Existing Criticals and Velocity are preserved.
All active targeting/attacking behavior is guarded to single-player. Settings are registered in BaseClient.init().

Important Reach integration: this source archive does not include PlayerControllerMP.java, so Reach is registered and configurable but does not extend actual hit/ray-trace distance yet. In the full Eaglercraft source, find the PlayerControllerMP reach-distance / entity ray-trace calculation and use Reach.getReachDistance() in place of the default 3.0D survival reach (keep the existing creative-mode behavior intact).

Build note: this archive is a partial source bundle, not a complete buildable project; no full compilation was possible from the supplied ZIP alone. Test in a local single-player world.
