BaseClient movement module patch
================================

Includes these modules, registered with the existing ModuleManager:
NoFall, Fly, Speed, HighJump, LongJump, Step, Jesus, Spider, NoSlow, SafeWalk, InventoryMove.

Settings added to the existing settings manager: Fly vertical speed, Speed multiplier,
HighJump height, LongJump boost, and Step height.

IMPORTANT INTEGRATION NOTES
- NoFall, Fly, Speed, HighJump, LongJump, Step, Jesus and Spider use local player state and are intended for single-player testing.
- NoSlow is a registered module flag only. Full functionality requires changing the vanilla movement/input slowdown path to skip slowdown while this module is toggled.
- SafeWalk is a registered module flag only. Reliable edge prevention requires a hook in the entity movement/collision path.
- InventoryMove is a registered module flag only. Movement while a GUI is open requires a GuiScreen/KeyBinding input hook.
- This archive contains a partial source bundle and was not compiled against the full Eaglercraft project. Integrate into a complete checkout and run its normal build before use.
- Existing combat modules, ESP, HUD, FullBright, Scaffold and Sprint are preserved; no duplicate ESP/HUD/FullBright modules are added.
