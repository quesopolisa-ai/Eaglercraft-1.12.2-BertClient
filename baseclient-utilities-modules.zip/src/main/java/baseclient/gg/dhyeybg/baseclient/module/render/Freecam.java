package baseclient.gg.dhyeybg.baseclient.module.render;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;

/** Freecam toggle placeholder. A detached camera requires EntityRenderer and input hooks. */
public class Freecam extends Module {
    public Freecam() { super("Freecam", "Toggle for detached camera mode (requires renderer/input integration)", Category.RENDER); }
}
