package baseclient.gg.dhyeybg.baseclient.module.combat;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;

/**
 * Config module for extended reach. PlayerControllerMP's reach/ray-trace logic must call
 * getReachDistance() for this setting to change actual targeting distance.
 */
public class Reach extends Module {
    private final Setting distance = Setting.textBox("Distance", this, 4.5D, 3.0D, 6.0D);
    public Reach() { super("Reach", "Configures extended interaction distance for local testing", Category.COMBAT); }
    public void registerSettings(SettingsManager sm) { sm.rSetting(distance); }
    public static double getReachDistance() {
        if (mc == null || !mc.isSingleplayer()) return 3.0D;
        try {
            if (baseclient.gg.dhyeybg.baseclient.BaseClient.instance == null || baseclient.gg.dhyeybg.baseclient.BaseClient.instance.moduleManager == null) return 3.0D;
            Reach mod = (Reach)baseclient.gg.dhyeybg.baseclient.BaseClient.instance.moduleManager.getModule("Reach");
            if (mod == null || !mod.isToggled()) return 3.0D;
            baseclient.gg.dhyeybg.baseclient.settings.SettingsManager sm = baseclient.gg.dhyeybg.baseclient.BaseClient.instance.settingsManager;
            if (sm == null) return 3.0D;
            return sm.getSettingByName(mod, "Distance").getValDouble();
        } catch (RuntimeException ex) { return 3.0D; }
    }
}
