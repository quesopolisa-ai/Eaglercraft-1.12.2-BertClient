package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Requires a GuiScreen/KeyBinding hook because vanilla screens suppress movement input. */
public class InventoryMove extends Module {
 public InventoryMove(){ super("InventoryMove", "Inventory movement flag; requires a GUI input hook", Category.MOVEMENT); }
}
