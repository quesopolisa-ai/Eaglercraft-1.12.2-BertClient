package baseclient.gg.dhyeybg.baseclient.module.combat;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

/** Attacks once per cooldown when the crosshair is already on a living entity. */
public class TriggerBot extends Module {
    private final Setting delay = Setting.textBox("Delay MS", this, 250.0D, 50.0D, 1000.0D);
    private long nextAttack;
    public TriggerBot() { super("TriggerBot", "Attacks a living crosshair target in single-player", Category.COMBAT); }
    public void registerSettings(SettingsManager sm) { sm.rSetting(delay); }
    @Override public void onEnable() { nextAttack = 0L; }
    @Override public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.playerController == null || !mc.isSingleplayer()) return;
        long now = System.currentTimeMillis();
        if (now < nextAttack) return;
        RayTraceResult hit = mc.objectMouseOver;
        if (hit == null || hit.typeOfHit != RayTraceResult.Type.ENTITY) return;
        Entity target = hit.entityHit;
        if (!(target instanceof EntityLivingBase) || target == mc.player || !target.isEntityAlive()) return;
        mc.playerController.attackEntity(mc.player, target);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        nextAttack = now + (long)delay.getValDouble();
    }
}
