package baseclient.gg.dhyeybg.baseclient.module.player;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;

/** Eats food from the selected hotbar slot when hunger is low. */
public class AutoEat extends Module {
    private final Setting hunger = Setting.textBox("Hunger Threshold", this, 15.0D, 1.0D, 19.0D);
    public AutoEat() { super("AutoEat", "Eats held food when hunger is below the threshold", Category.PLAYER); }
    public void registerSettings(SettingsManager sm) { sm.rSetting(hunger); }
    @Override public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.playerController == null || !mc.isSingleplayer()) return;
        if (mc.player.getFoodStats().getFoodLevel() >= (int) hunger.getValDouble() || mc.player.isHandActive()) return;
        ItemStack stack = mc.player.getHeldItemMainhand();
        if (!stack.isEmpty() && stack.getItem() instanceof ItemFood) mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
    }
}
