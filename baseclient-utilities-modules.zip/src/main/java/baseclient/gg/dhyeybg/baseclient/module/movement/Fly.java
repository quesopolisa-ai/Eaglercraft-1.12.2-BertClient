package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class Fly extends Module {
 private final Setting speed = Setting.textBox("Vertical Speed", this, 0.35D, 0.05D, 1.5D);
 public Fly(){ super("Fly", "Simple local flight controls for single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(speed); }
 @Override public void onUpdate(){ if(mc.player == null || !mc.isSingleplayer()) return; if(mc.gameSettings.keyBindJump.isKeyDown()) mc.player.motionY = speed.getValDouble(); else if(mc.gameSettings.keyBindSneak.isKeyDown()) mc.player.motionY = -speed.getValDouble(); else mc.player.motionY = 0.0D; mc.player.fallDistance = 0.0F; }
 @Override public void onDisable(){ if(mc.player != null) mc.player.motionY = 0.0D; }
}
