package baseclient.gg.dhyeybg.baseclient.module.player;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.item.ItemStack;

/** Selects the best hotbar tool for the block under the crosshair. */
public class AutoTool extends Module {
    public AutoTool() { super("AutoTool", "Selects the best hotbar tool for the targeted block", Category.PLAYER); }
    @Override public void onUpdate() {
        if (mc.player == null || mc.world == null || !mc.isSingleplayer()) return;
        RayTraceResult hit = mc.objectMouseOver;
        if (hit == null || hit.typeOfHit != RayTraceResult.Type.BLOCK || hit.getBlockPos() == null) return;
        BlockPos pos = hit.getBlockPos();
        IBlockState state = mc.world.getBlockState(pos);
        int bestSlot = mc.player.inventory.currentItem;
        float bestSpeed = -1.0F;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            float speed = stack.isEmpty() ? 1.0F : stack.getDestroySpeed(state);
            if (speed > bestSpeed) { bestSpeed = speed; bestSlot = i; }
        }
        mc.player.inventory.currentItem = bestSlot;
    }
}
