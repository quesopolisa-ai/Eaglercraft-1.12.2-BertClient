package baseclient.gg.dhyeybg.baseclient.module.misc;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {

    private int previousSlot = -1;

    public Scaffold() {
        super("Scaffold", "Places blocks under you in single-player", Category.MISC);
    }

    @Override
    public void onDisable() {
        restoreSlot();
    }

    @Override
    public void onUpdate() {
        if (mc == null || mc.player == null || mc.world == null || mc.playerController == null
                || mc.currentScreen != null || !mc.isSingleplayer()) {
            restoreSlot();
            return;
        }

        BlockPos target = new BlockPos(mc.player.posX, mc.player.getEntityBoundingBox().minY - 0.5D, mc.player.posZ);
        if (!mc.world.getBlockState(target).getMaterial().isReplaceable()) {
            restoreSlot();
            return;
        }

        BlockPos support = null;
        EnumFacing clickedFace = null;
        for (EnumFacing facing : EnumFacing.values()) {
            BlockPos neighbor = target.offset(facing);
            if (mc.world.getBlockState(neighbor).getMaterial().isSolid()) {
                support = neighbor;
                clickedFace = facing.getOpposite();
                break;
            }
        }
        if (support == null) {
            restoreSlot();
            return;
        }

        int slot = findBlockSlot();
        if (slot == -1) {
            restoreSlot();
            return;
        }

        if (previousSlot == -1) {
            previousSlot = mc.player.inventory.currentItem;
        }
        mc.player.inventory.currentItem = slot;

        Vec3d hitVec = new Vec3d(
                support.getX() + 0.5D + (target.getX() - support.getX()) * 0.5D,
                support.getY() + 0.5D + (target.getY() - support.getY()) * 0.5D,
                support.getZ() + 0.5D + (target.getZ() - support.getZ()) * 0.5D);
        EnumActionResult result = mc.playerController.processRightClickBlock(mc.player, mc.world, support,
                clickedFace, hitVec, EnumHand.MAIN_HAND);
        if (result == EnumActionResult.SUCCESS) {
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
    }

    private void restoreSlot() {
        if (previousSlot != -1 && mc != null && mc.player != null) {
            mc.player.inventory.currentItem = previousSlot;
        }
        previousSlot = -1;
    }

    private int findBlockSlot() {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(slot);
            if (stack == null || stack.func_190926_b() || !(stack.getItem() instanceof ItemBlock)) {
                continue;
            }
            Block block = ((ItemBlock) stack.getItem()).getBlock();
            IBlockState state = block.getDefaultState();
            if (block instanceof BlockFalling || block instanceof ITileEntityProvider || !state.isFullCube()) {
                continue;
            }
            return slot;
        }
        return -1;
    }
}
