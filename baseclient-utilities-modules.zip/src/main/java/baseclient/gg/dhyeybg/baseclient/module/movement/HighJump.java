package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class HighJump extends Module {
 private final Setting height=Setting.textBox("Height", this, 0.65D, 0.42D, 1.5D); private boolean wasOnGround;
 public HighJump(){ super("HighJump", "Boosts each grounded jump in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(height); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.onGround && mc.player.movementInput.jump && !wasOnGround) mc.player.motionY=height.getValDouble(); wasOnGround=mc.player.onGround; }
 @Override public void onDisable(){ wasOnGround=false; }
}
