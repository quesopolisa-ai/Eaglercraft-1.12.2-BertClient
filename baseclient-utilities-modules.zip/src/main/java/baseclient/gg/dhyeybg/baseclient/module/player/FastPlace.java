package baseclient.gg.dhyeybg.baseclient.module.player;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;

/** Reduces the local right-click delay for faster placement in single-player. */
public class FastPlace extends Module {
    public FastPlace() { super("FastPlace", "Reduces right-click placement delay", Category.PLAYER); }
    @Override public void onUpdate() {
        if (mc.player != null && mc.isSingleplayer() && mc.rightClickDelayTimer > 0) mc.rightClickDelayTimer = 0;
    }
}
