package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class Speed extends Module {
 private final Setting multiplier = Setting.textBox("Multiplier", this, 1.35D, 1.05D, 2.5D);
 public Speed(){ super("Speed", "Increases ground movement speed in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(multiplier); }
 @Override public void onUpdate(){ if(mc.player == null || !mc.isSingleplayer() || mc.player.movementInput == null) return; double f=mc.player.movementInput.moveForward, s=mc.player.movementInput.moveStrafe; if(f==0.0D && s==0.0D) return; float yaw=mc.player.rotationYaw; if(f!=0.0D){ if(s>0) yaw += f>0? -45:45; else if(s<0) yaw += f>0?45:-45; s=0; f=f>0?1:-1; } double r=Math.toRadians(yaw); double scale=0.1D*(multiplier.getValDouble()-1.0D); mc.player.motionX += (-Math.sin(r)*f + Math.cos(r)*s)*scale; mc.player.motionZ += (Math.cos(r)*f + Math.sin(r)*s)*scale; }
}
