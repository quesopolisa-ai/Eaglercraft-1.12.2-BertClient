package baseclient.gg.dhyeybg.baseclient.module.player;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;

/** Adjusts client tick length in single-player. */
public class Timer extends Module {
    private final Setting speed = Setting.textBox("Tick Speed", this, 1.5D, 0.5D, 3.0D);
    private float originalTickLength = 50.0F;
    public Timer() { super("Timer", "Adjusts local game tick speed", Category.PLAYER); }
    public void registerSettings(SettingsManager sm) { sm.rSetting(speed); }
    @Override public void onEnable() { if (mc.timer != null) originalTickLength = mc.timer.tickLength; }
    @Override public void onUpdate() { if (mc.isSingleplayer() && mc.timer != null) mc.timer.tickLength = (float)(50.0D / speed.getValDouble()); }
    @Override public void onDisable() { if (mc.timer != null) mc.timer.tickLength = originalTickLength; }
}
