package baseclient.gg.dhyeybg.baseclient.module.render;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;

/** XRay toggle placeholder. Rendering blocks through walls requires a WorldRenderer/block-render hook. */
public class XRay extends Module {
    public XRay() { super("XRay", "Toggle for the XRay render hook (requires renderer integration)", Category.RENDER); }
}
