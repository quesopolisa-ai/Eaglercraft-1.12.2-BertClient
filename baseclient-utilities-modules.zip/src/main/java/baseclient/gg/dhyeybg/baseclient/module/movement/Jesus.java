package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
public class Jesus extends Module {
 public Jesus(){ super("Jesus", "Keeps the player afloat on water in single-player", Category.MOVEMENT); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.isInWater() && !mc.player.isSneaking() && mc.player.motionY < 0.0D) mc.player.motionY=0.08D; }
}
