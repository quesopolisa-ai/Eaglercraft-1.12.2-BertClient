package baseclient.gg.dhyeybg.baseclient.module.combat;

import baseclient.gg.dhyeybg.baseclient.BaseClient;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketPlayer;

public class Criticals extends Module {

    private static final double HOP_HEIGHT = 0.0625D;

    public Criticals() {
        super("Criticals", "Forces critical hits in single-player", Category.COMBAT);
    }

    private static boolean isActive() {
        BaseClient client = BaseClient.instance;
        if (client == null || client.moduleManager == null) {
            return false;
        }
        Module criticals = client.moduleManager.getModule("Criticals");
        return criticals != null && criticals.isToggled();
    }

    /**
     * Kept for the server-side hook in EntityPlayer. The integrated server may run in its own
     * context where BaseClient.instance is null, in which case this simply returns false.
     */
    public static boolean isEnabledForSingleplayer() {
        return isActive() && Minecraft.getMinecraft().isSingleplayer();
    }

    /**
     * Called from PlayerControllerMP.attackEntity just before the use-entity packet is sent.
     * Two position packets make the server see the player falling (fallDistance > 0 and not on
     * the ground), so the server's own critical-hit check passes.
     */
    public static void onAttack(Entity target) {
        if (!(target instanceof EntityLivingBase) || !isActive()) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.player.connection == null || !mc.isSingleplayer()) {
            return;
        }
        if (mc.player.isInWater() || mc.player.isInLava() || mc.player.isOnLadder() || mc.player.isRiding()) {
            return;
        }
        double x = mc.player.posX;
        double y = mc.player.posY;
        double z = mc.player.posZ;
        mc.player.connection.sendPacket(new CPacketPlayer.Position(x, y + HOP_HEIGHT, z, false));
        mc.player.connection.sendPacket(new CPacketPlayer.Position(x, y, z, false));
    }
}
