package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Resets local fall distance; intended for single-player testing. */
public class NoFall extends Module {
 public NoFall(){ super("NoFall", "Prevents fall damage in single-player", Category.MOVEMENT); }
 @Override public void onUpdate(){ if(mc.player != null && mc.isSingleplayer()) mc.player.fallDistance = 0.0F; }
}
