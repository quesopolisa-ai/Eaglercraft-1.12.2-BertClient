package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class Step extends Module {
 private final Setting height=Setting.textBox("Height", this, 1.0D, 0.6D, 2.5D); private float oldHeight=0.6F;
 public Step(){ super("Step", "Steps up higher blocks in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(height); }
 @Override public void onEnable(){ if(mc.player!=null){ oldHeight=mc.player.stepHeight; mc.player.stepHeight=(float)height.getValDouble(); } }
 @Override public void onUpdate(){ if(mc.player!=null && mc.isSingleplayer()) mc.player.stepHeight=(float)height.getValDouble(); }
 @Override public void onDisable(){ if(mc.player!=null) mc.player.stepHeight=0.6F; }
}
