package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Module flag only: vanilla slowdown is applied in movement/input code and needs a hook to fully cancel. */
public class NoSlow extends Module {
 public NoSlow(){ super("NoSlow", "No-slow module flag; requires a movement-input hook", Category.MOVEMENT); }
}
