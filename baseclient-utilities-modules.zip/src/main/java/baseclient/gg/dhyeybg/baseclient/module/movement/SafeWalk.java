package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
/** Needs an Entity movement/collision hook to prevent walking off edges reliably. */
public class SafeWalk extends Module {
 public SafeWalk(){ super("SafeWalk", "Safe-walk module flag; requires a movement hook", Category.MOVEMENT); }
}
