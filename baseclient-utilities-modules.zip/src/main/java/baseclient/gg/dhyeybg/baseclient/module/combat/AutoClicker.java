package baseclient.gg.dhyeybg.baseclient.module.combat;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

/** Repeatedly attacks the entity currently under the crosshair, in single-player only. */
public class AutoClicker extends Module {
    private final Setting cps = Setting.textBox("CPS", this, 8.0D, 1.0D, 20.0D);
    private long nextClick;
    public AutoClicker() { super("AutoClicker", "Automatically attacks the crosshair target in single-player", Category.COMBAT); }
    public void registerSettings(SettingsManager sm) { sm.rSetting(cps); }
    @Override public void onEnable() { nextClick = 0L; }
    @Override public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.playerController == null || !mc.isSingleplayer()) return;
        long now = System.currentTimeMillis();
        if (now < nextClick) return;
        RayTraceResult hit = mc.objectMouseOver;
        if (hit == null || hit.typeOfHit != RayTraceResult.Type.ENTITY || !(hit.entityHit instanceof EntityLivingBase)) return;
        Entity target = hit.entityHit;
        if (!target.isEntityAlive() || target == mc.player) return;
        mc.playerController.attackEntity(mc.player, target);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        nextClick = now + Math.max(50L, (long)(1000.0D / cps.getValDouble()));
    }
}
