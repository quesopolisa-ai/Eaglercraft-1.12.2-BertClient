package baseclient.gg.dhyeybg.baseclient.module.combat;

import baseclient.gg.dhyeybg.baseclient.BaseClient;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;

/** Local single-player aim assistance. */
public class AimAssist extends Module {
    private final Setting players = new Setting("Players", this, true);
    private final Setting mobs = new Setting("Mobs", this, true);
    private final Setting range = Setting.textBox("Range", this, 4.0D, 1.0D, 8.0D);
    private final Setting smoothing = Setting.textBox("Smoothing", this, 5.0D, 1.0D, 20.0D);

    public AimAssist() { super("AimAssist", "Gently aims at nearby entities in single-player", Category.COMBAT); }
    public void registerSettings(SettingsManager sm) { sm.rSetting(players); sm.rSetting(mobs); sm.rSetting(range); sm.rSetting(smoothing); }

    @Override public void onUpdate() {
        if (mc.player == null || mc.world == null || !mc.isSingleplayer()) return;
        EntityLivingBase target = null;
        double best = range.getValDouble() * range.getValDouble();
        for (Entity e : mc.world.loadedEntityList) {
            if (!(e instanceof EntityLivingBase) || e == mc.player || !e.isEntityAlive()) continue;
            if (e instanceof EntityPlayer ? !players.getValBoolean() : !mobs.getValBoolean()) continue;
            double d = mc.player.getDistanceSq(e);
            if (d < best) { best = d; target = (EntityLivingBase)e; }
        }
        if (target == null) return;
        double dx = target.posX - mc.player.posX;
        double dz = target.posZ - mc.player.posZ;
        double dy = target.posY + target.getEyeHeight() * 0.75D - (mc.player.posY + mc.player.getEyeHeight());
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horizontal)));
        float step = (float)Math.max(1.0D, smoothing.getValDouble());
        mc.player.rotationYaw += MathHelper.wrapDegrees(yaw - mc.player.rotationYaw) / step;
        mc.player.rotationPitch += MathHelper.wrapDegrees(pitch - mc.player.rotationPitch) / step;
        mc.player.rotationPitch = MathHelper.clamp(mc.player.rotationPitch, -90.0F, 90.0F);
    }
}
