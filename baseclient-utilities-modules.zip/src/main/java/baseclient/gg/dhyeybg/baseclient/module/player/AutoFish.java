package baseclient.gg.dhyeybg.baseclient.module.player;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;

/** Basic single-player fishing helper: reels in when the bobber is pulled under water. */
public class AutoFish extends Module {
    public AutoFish() { super("AutoFish", "Reels in when the fishing bobber indicates a bite", Category.PLAYER); }
    @Override public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.playerController == null || !mc.isSingleplayer()) return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held.isEmpty() || !(held.getItem() instanceof ItemFishingRod)) return;
        EntityFishHook hook = mc.player.fishEntity;
        if (hook != null && hook.isInWater() && hook.motionY < -0.04D) mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
    }
}
