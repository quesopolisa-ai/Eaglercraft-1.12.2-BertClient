package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import baseclient.gg.dhyeybg.baseclient.settings.Setting;
import baseclient.gg.dhyeybg.baseclient.settings.SettingsManager;
public class LongJump extends Module {
 private final Setting boost=Setting.textBox("Boost", this, 0.35D, 0.05D, 1.0D); private boolean wasOnGround;
 public LongJump(){ super("LongJump", "Adds a forward jump boost in single-player", Category.MOVEMENT); }
 public void registerSettings(SettingsManager sm){ sm.rSetting(boost); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.onGround && mc.player.movementInput.jump && !wasOnGround){ double f=mc.player.movementInput.moveForward, s=mc.player.movementInput.moveStrafe; if(f!=0 || s!=0){ double yaw=Math.toRadians(mc.player.rotationYaw); mc.player.motionX += (-Math.sin(yaw)*f + Math.cos(yaw)*s)*boost.getValDouble(); mc.player.motionZ += (Math.cos(yaw)*f + Math.sin(yaw)*s)*boost.getValDouble(); } } wasOnGround=mc.player.onGround; }
 @Override public void onDisable(){ wasOnGround=false; }
}
