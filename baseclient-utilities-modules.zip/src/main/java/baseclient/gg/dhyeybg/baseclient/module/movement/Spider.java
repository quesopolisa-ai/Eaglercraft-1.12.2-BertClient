package baseclient.gg.dhyeybg.baseclient.module.movement;
import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
public class Spider extends Module {
 public Spider(){ super("Spider", "Climbs walls when colliding in single-player", Category.MOVEMENT); }
 @Override public void onUpdate(){ if(mc.player==null || !mc.isSingleplayer()) return; if(mc.player.isCollidedHorizontally && (mc.player.movementInput.moveForward!=0 || mc.player.movementInput.moveStrafe!=0)) mc.player.motionY=0.2D; }
}
