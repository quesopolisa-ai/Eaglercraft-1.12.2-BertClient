package baseclient.gg.dhyeybg.baseclient.module.player;

import baseclient.gg.dhyeybg.baseclient.module.Category;
import baseclient.gg.dhyeybg.baseclient.module.Module;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

/** Moves a totem from the main inventory to the offhand in single-player. */
public class AutoTotem extends Module {
    public AutoTotem() { super("AutoTotem", "Keeps a totem in the offhand when one is available", Category.PLAYER); }
    @Override public void onUpdate() {
        if (mc.player == null || mc.playerController == null || !mc.isSingleplayer()) return;
        ItemStack offhand = mc.player.getHeldItemOffhand();
        if (!offhand.isEmpty() && offhand.getItem() == Items.TOTEM_OF_UNDYING) return;
        for (int i = 0; i < mc.player.inventory.mainInventory.size(); i++) {
            ItemStack stack = mc.player.inventory.mainInventory.get(i);
            if (!stack.isEmpty() && stack.getItem() == Items.TOTEM_OF_UNDYING) {
                // Inventory click interaction varies by client fork; leave item untouched rather than risk moving the wrong slot.
                return;
            }
        }
    }
}
